<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $transaction_id = $_GET['id'];
    $sql = "SELECT * FROM transactions WHERE id = '$transaction_id' AND user_id = '" . $_SESSION['user_id'] . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $transaction = $result->fetch_assoc();
    } else {
        echo "Transaction not found!";
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date = $_POST['date'];
    $description = $_POST['description'];
    $amount = $_POST['amount'];
    $type = $_POST['type'];

    $update_sql = "UPDATE transactions SET date = '$date', description = '$description', amount = '$amount', type = '$type' WHERE id = '$transaction_id' AND user_id = '" . $_SESSION['user_id'] . "'";

    if ($conn->query($update_sql) === TRUE) {
        header("Location: index.php");
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Transaction</title>
</head>
<body>
    <h1>Edit Transaction</h1>
    <form method="POST" action="">
        <label>
            Date: <input type="date" name="date" value="<?php echo $transaction['date']; ?>" required>
        </label>
        <br>
        <label>
            Description: <input type="text" name="description" value="<?php echo $transaction['description']; ?>" required>
        </label>
        <br>
        <label>
            Amount: <input type="number" name="amount" value="<?php echo $transaction['amount']; ?>" required>
        </label>
        <br>
        <label>
            Type: 
            <select name="type" required>
                <option value="income" <?php echo ($transaction['type'] == 'income') ? 'selected' : ''; ?>>Income</option>
                <option value="expense" <?php echo ($transaction['type'] == 'expense') ? 'selected' : ''; ?>>Expense</option>
            </select>
        </label>
        <br>
        <button type="submit">Update Transaction</button>
    </form>
    <a href="index.php">Back to Dashboard</a>
</body>
</html>
