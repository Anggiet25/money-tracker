<?php
require 'vendor/autoload.php'; // Pastikan ini sesuai dengan lokasi library PhpSpreadsheet Anda.

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

include 'db.php'; // Sambungkan dengan database.

// Pastikan user_id terdefinisi, misalnya dari session atau parameter GET
session_start();
if (!isset($_SESSION['user_id'])) {
    die("User ID tidak ditemukan. Pastikan Anda sudah login.");
}

$user_id = $_SESSION['user_id']; // Ambil user_id dari session

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle('Financial Report');

    $currentRow = 1; // Mulai dari baris pertama

    // Header untuk tabel income
    $sheet->setCellValue('A' . $currentRow, 'Tabel Income');
    $currentRow++;
    $sheet->setCellValue('A' . $currentRow, 'Tanggal');
    $sheet->setCellValue('B' . $currentRow, 'Nama Transaksi');
    $sheet->setCellValue('C' . $currentRow, 'Nominal');
    $currentRow++;

    // Ambil data income dari database
    $sql_income = "SELECT date, description, amount FROM transactions WHERE user_id = ? AND type = 'income' ORDER BY date ASC";
    $stmt_income = $conn->prepare($sql_income);
    $stmt_income->bind_param("i", $user_id);
    $stmt_income->execute();
    $result_income = $stmt_income->get_result();

    $totalIncome = 0;
    while ($data = $result_income->fetch_assoc()) {
        $sheet->setCellValue('A' . $currentRow, $data['date']);
        $sheet->setCellValue('B' . $currentRow, $data['description']);
        $sheet->setCellValue('C' . $currentRow, $data['amount']);
        $sheet->getStyle('C' . $currentRow)->getNumberFormat()->setFormatCode('"Rp" #,##0.00'); // Format Rupiah
        $totalIncome += $data['amount'];
        $currentRow++;
    }

    // Tambahkan baris kosong setelah tabel income
    $currentRow++;

    // Header untuk tabel outcome
    $sheet->setCellValue('A' . $currentRow, 'Tabel Outcome');
    $currentRow++;
    $sheet->setCellValue('A' . $currentRow, 'Tanggal');
    $sheet->setCellValue('B' . $currentRow, 'Nama Transaksi');
    $sheet->setCellValue('C' . $currentRow, 'Nominal');
    $currentRow++;

    // Ambil data outcome dari database
    $sql_outcome = "SELECT date, description, amount FROM transactions WHERE user_id = ? AND type = 'expense' ORDER BY date ASC";
    $stmt_outcome = $conn->prepare($sql_outcome);
    $stmt_outcome->bind_param("i", $user_id);
    $stmt_outcome->execute();
    $result_outcome = $stmt_outcome->get_result();

    $totalOutcome = 0;
    while ($data = $result_outcome->fetch_assoc()) {
        $sheet->setCellValue('A' . $currentRow, $data['date']);
        $sheet->setCellValue('B' . $currentRow, $data['description']);
        $sheet->setCellValue('C' . $currentRow, $data['amount']);
        $sheet->getStyle('C' . $currentRow)->getNumberFormat()->setFormatCode('"Rp" #,##0.00'); // Format Rupiah
        $totalOutcome += $data['amount'];
        $currentRow++;
    }

    // Tambahkan baris kosong setelah tabel outcome
    $currentRow++;

    // Tambahkan total income, outcome, dan nominal keseluruhan
    $sheet->setCellValue('B' . $currentRow, 'Total Income:');
    $sheet->setCellValue('C' . $currentRow, $totalIncome);
    $sheet->getStyle('C' . $currentRow)->getNumberFormat()->setFormatCode('"Rp" #,##0.00'); // Format Rupiah
    $currentRow++;

    $sheet->setCellValue('B' . $currentRow, 'Total Outcome:');
    $sheet->setCellValue('C' . $currentRow, $totalOutcome);
    $sheet->getStyle('C' . $currentRow)->getNumberFormat()->setFormatCode('"Rp" #,##0.00'); // Format Rupiah
    $currentRow++;

    $sheet->setCellValue('B' . $currentRow, 'Total Keseluruhan:');
    $sheet->setCellValue('C' . $currentRow, $totalIncome - $totalOutcome);
    $sheet->getStyle('C' . $currentRow)->getNumberFormat()->setFormatCode('"Rp" #,##0.00'); // Format Rupiah

    // Simpan file Excel
    $filename = "Rincian_Keuangan_Tabel.xlsx";
    $writer = new Xlsx($spreadsheet);

    // Download file
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    $writer->save('php://output');
    exit;
}
?>
