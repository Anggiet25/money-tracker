<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $transaction_id = $_GET['id'];
    $delete_sql = "DELETE FROM transactions WHERE id = '$transaction_id' AND user_id = '" . $_SESSION['user_id'] . "'";
    if ($conn->query($delete_sql) === TRUE) {
        header("Location: index.php");
        exit;
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}
?>
