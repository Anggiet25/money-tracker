<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

include 'db.php';
$user_id = $_SESSION['user_id'];

$sql_income = "SELECT * FROM transactions WHERE user_id = '$user_id' AND type = 'income' ORDER BY date DESC";
$result_income = $conn->query($sql_income);

$sql_outcome = "SELECT * FROM transactions WHERE user_id = '$user_id' AND type = 'expense' ORDER BY date DESC";
$result_outcome = $conn->query($sql_outcome);

// Hitung total income
$sql_total_income = "SELECT SUM(amount) AS total_income FROM transactions WHERE user_id = '$user_id' AND type = 'income'";
$total_income_result = $conn->query($sql_total_income);
$total_income = $total_income_result->fetch_assoc()['total_income'] ?? 0;

// Hitung total outcome
$sql_total_outcome = "SELECT SUM(amount) AS total_outcome FROM transactions WHERE user_id = '$user_id' AND type = 'expense'";
$total_outcome_result = $conn->query($sql_total_outcome);
$total_outcome = $total_outcome_result->fetch_assoc()['total_outcome'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- CDN Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        table, th, td { border: 1px solid #ddd; padding: 20px; text-align: left;  top: 5px; left:10px; }
        th, td { padding: 12px; text-align: left; }
        th { background-color: #f4f4f4; }
        .total { font-weight: bold; text-align: right; }
        .section { margin-bottom: 40px; }

        /* Styling untuk tombol actions */
        .action-btns {
            position: relative;
            display: inline-block;
            cursor: pointer;
            text-align: center;
        }

        .action-btns .fa-bars {
            font-size: 20px; /* Ukuran ikon lebih kecil agar lebih proporsional */
            color: #333;
            line-height: 1;
            margin: 0; /* Menghilangkan margin untuk lebih rapi */
            padding: 8px; /* Padding di sekitar ikon untuk membuatnya lebih seperti tombol */
            border-radius: 5px; /* Membuat tombol bulat */
            transition: background-color 0.2s ease, transform 0.2s ease;
        }

        .action-btns .fa-bars:hover {
            background-color: #f0f0f0; /* Warna latar belakang berubah saat hover */
            transform: scale(1.1); /* Agak membesar saat di-hover */
        }

       
        /* Dropdown menu styling */
        .more-options {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background-color: #fff;
            border: 1px solid #ddd;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            min-width: 120px;
            z-index: 1;
            border-radius: 4px;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.2s ease-in-out;
        }

        .more-options a {
            color: #007BFF;
            padding: 10px 15px;
            text-decoration: none;
            display: block;
            font-size: 14px;
            transition: background-color 0.2s ease-in-out;
        }

        .more-options a:hover {
            background-color: #f0f0f0;
        }

        /* Menampilkan dropdown ketika tombol diklik */
        .action-btns.active .more-options {
            display: block;
            opacity: 1;
            pointer-events: auto;
        }

        /* Memastikan garis tabel pada kolom Actions sejajar dengan ikon */
        td.action-btns {
            vertical-align: middle; /* Menyelaraskan ikon dengan teks */
            padding: 0; /* Mengurangi padding agar lebih rapih */
            width: 50px; /* Lebar tetap untuk kolom Action */
        }

        /* Hover untuk seluruh baris tabel */
        tr:hover {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
    <a href="logout.php">Logout</a>
    <hr>

    <!-- Form untuk menambahkan transaksi -->
    <h2>Add Transaction</h2>
    <div class="form-container">
    <form method="POST" action="add_transaction.php">
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" required>
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <input type="text" id="description" name="description" required>
            </div>
            <div class="form-group">
                <label for="amount">Amount:</label>
                <input type="number" id="amount" name="amount" required>
            </div>
            <div class="form-group">
                <label for="type">Type:</label>
                <select id="type" name="type" required>
                    <option value="income">Income</option>
                    <option value="expense">Expense</option>
                </select>
            </div>
            <button type="submit">Add Transaction</button>
        </form>
    </div>
    
    <hr>

    <!-- Tabel untuk income (pemasukan) -->
    <div class="section">
        <h2>Income (Pemasukan)</h2>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result_income->num_rows > 0) {
                    while ($row = $result_income->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['description']) . "</td>";
                        echo "<td>Rp " . number_format($row['amount'], 2, ',', '.') . "</td>"; // Format Rupiah
                        echo "<td class='action-btns'>";
                        echo "<i class='fa-solid fa-bars'></i>"; // Ikon titik tiga yang berubah jadi tombol
                        echo "<div class='more-options'>";
                        echo "<a href='edit_transaction.php?id=" . $row['id'] . "'>Edit</a>";
                        echo "<a href='delete_transaction.php?id=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this transaction?\");'>Delete</a>";
                        echo "</div>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No income found.</td></tr>";
                }
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="2" class="total">Total Income:</td>
                    <td><?php echo "Rp " . number_format($total_income, 2); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <!-- Tabel untuk outcome (pengeluaran) -->
    <div class="section">
        <h2>Outcome (Pengeluaran)</h2>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result_outcome->num_rows > 0) {
                    while ($row = $result_outcome->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['description']) . "</td>";
                        echo "<td>Rp " . number_format($row['amount'], 2, ',', '.') . "</td>"; // Format Rupiah
                        echo "<td class='action-btns'>";
                        echo "<i class='fa-solid fa-bars'></i>"; // Ikon titik tiga yang berubah jadi tombol
                        echo "<div class='more-options'>";
                        echo "<a href='edit_transaction.php?id=" . $row['id'] . "'>Edit</a>";
                        echo "<a href='delete_transaction.php?id=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this transaction?\");'>Delete</a>";
                        echo "</div>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No outcome found.</td></tr>";
                }
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="2" class="total">Total Outcome:</td>
                    <td><?php echo "Rp ". number_format($total_outcome, 2); ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
    <div class="section">
        <h2 style=text-align:center;>Sisa Keuangan</h2>
        <table>
            <thead>
                <tr>
                    <td style=text-align:right; >Sisa Uang : </td>
                <td><?php echo"Rp ". number_format($total_income - $total_outcome);
                ?>
                </td>
                </tr>
                
            </thead>
        </table>
    </div>

    <script>
        // Script untuk toggle dropdown saat tombol diklik
        document.querySelectorAll('.action-btns').forEach(function(button) {
            button.addEventListener('click', function() {
                this.classList.toggle('active');
            });
        });
    </script>
    <a href="export_excel.php" class="btn btn-success">Download Excel</a>

</body>
</html>
