dokumentasi website money-tracker
1. Database menggunakan mysql, dengan nama database : money-tracker
2. table database : 
-- Buat database
CREATE DATABASE money_tracker;

-- Gunakan database
USE money_tracker;

-- Buat tabel users
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Buat tabel transactions
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date DATE NOT NULL,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(15, 2) NOT NULL,
    type ENUM('income', 'expense') NOT NULL,
    user_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);


2. connection database ada di db.php
3. kemudian untuk hostingnya menggunakan : infinityfree.com
domain : money-tracker.free.nf
4. upload hostinganya menggunakan ftp dengan filezilla.

