<?php
$host = "localhost";
$user = "root"; // Ganti jika ada username berbeda
$password = ""; // Ganti jika ada password berbeda
$database = "money_tracker";

$conn = new mysqli($host, $user, $password, $database);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
